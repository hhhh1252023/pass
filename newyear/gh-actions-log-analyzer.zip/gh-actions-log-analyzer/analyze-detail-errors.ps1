param(
    [string]$LogsDir = ".\logs",
    [string]$OutputDir = "."
)

$outputFile = Join-Path $OutputDir "failed_tests_detail.csv"
$outputJson = Join-Path $OutputDir "failed_tests_detail.json"

$csvContent = @()
$allRecords = @()

$failedJobs = Get-ChildItem $logsDir -Directory | Where-Object { 
    $jobInfoPath = Join-Path $_.FullName "job-info.json"
    if (Test-Path $jobInfoPath) {
        $jobInfo = Get-Content $jobInfoPath -Raw | ConvertFrom-Json
        return $jobInfo.conclusion -eq "failure"
    }
    return $false
}

foreach ($job in $failedJobs) {
    $jobName = $job.Name
    $logFile = Join-Path $job.FullName "full-log.txt"
    
    if (-not (Test-Path $logFile)) { continue }
    
    $logLines = Get-Content $logFile
    
    $currentTest = ""
    $errorBuffer = @()
    $inErrorBlock = $false
    
    for ($i = 0; $i -lt $logLines.Count; $i++) {
        $line = $logLines[$i]
        
        if ($line -match "FAILED:\s*(/\S+test_npu\S+\.py)") {
            $testPath = $matches[1]
            $testName = $testPath -replace '.*/test_npu_', '' -replace '\.py$', ''
            
            $fullError = ""
            $errorCode = ""
            $errorType = ""
            $errorContext = @()
            
            $searchStart = [Math]::Max(0, $i - 100)
            for ($j = $searchStart; $j -lt $i; $j++) {
                $prevLine = $logLines[$j]
                
                if ($prevLine -match "Traceback \(most recent call last\)") {
                    $errorType = "PythonException"
                    $errorBlock = @()
                    $contextLines = @()
                    for ($k = $j; $k -lt [Math]::Min($j + 30, $i); $k++) {
                        $errorBlock += $logLines[$k].Trim()
                        $contextLines += $logLines[$k]
                        if ($logLines[$k] -match "^[A-Z][a-zA-Z]+Error:|^ERROR:|^ModuleNotFoundError:|^ImportError:|^AttributeError:|^RuntimeError:|^AssertionError:|^ValueError:|^TypeError:|^KeyError:|^IndexError:") {
                            $fullError = $logLines[$k]
                            break
                        }
                    }
                    if ($fullError -eq "") {
                        $fullError = ($errorBlock | Select-Object -Last 3) -join " | "
                    }
                    $errorContext = $contextLines | Select-Object -Last 10
                }
                
                if ($prevLine -match "AttributeError: module 'triton\.language' has no attribute '(\w+)'" -and $errorType -eq "") {
                    $errorType = "TritonError"
                    $errorCode = $matches[1]
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 5); $k -lt [Math]::Min($j + 10, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "ImportError: cannot import name '([^']+)' from" -and $errorType -eq "") {
                    $errorType = "ImportError"
                    $errorCode = $matches[1]
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 3); $k -lt [Math]::Min($j + 5, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "ModuleNotFoundError: No module named '([^']+)'") {
                    $errorType = "ModuleNotFoundError"
                    $errorCode = $matches[1]
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 3); $k -lt [Math]::Min($j + 5, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "RuntimeError:.*NPU function error.*error code is (\d+)") {
                    $errorType = "NPUError"
                    $errorCode = $matches[1]
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 5); $k -lt [Math]::Min($j + 10, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "AttributeError: '([^']+Config)' object has no attribute '([^']+)'") {
                    $errorType = "ConfigError"
                    $errorCode = "$($matches[1]) missing $($matches[2])"
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 3); $k -lt [Math]::Min($j + 5, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "\[ERROR\].*ERR\d+") {
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 3); $k -lt [Math]::Min($j + 5, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
                
                if ($prevLine -match "AssertionError:") {
                    $errorType = "AssertionError"
                    $fullError = $prevLine.Trim()
                    for ($k = [Math]::Max(0, $j - 5); $k -lt [Math]::Min($j + 10, $logLines.Count); $k++) {
                        $errorContext += $logLines[$k]
                    }
                }
            }
            
            if ($fullError -eq "") {
                $fullError = "Unknown error - check log around line $i"
            }
            
            $detailedError = $fullError
            if ($errorContext.Count -gt 0) {
                $detailedError = ($errorContext | Where-Object { $_.Trim() -ne "" }) -join "`n"
            }
            
            $record = [PSCustomObject]@{
                JobName = $jobName
                TestName = $testName
                TestPath = $testPath
                ErrorType = $errorType
                ErrorCode = $errorCode
                OriginalError = $fullError
                ErrorDetail = $detailedError
            }
            
            $csvContent += $record
            $allRecords += $record
        }
    }
}

$csvContent | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8

$allRecords | ConvertTo-Json -Depth 10 | Out-File $outputJson -Encoding UTF8

Write-Host "CSV file saved: $outputFile"
Write-Host "JSON file saved: $outputJson"
Write-Host "Total failed tests: $($csvContent.Count)"

$csvContent | Format-Table -AutoSize