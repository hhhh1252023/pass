$data = Import-Csv .\failed_tests_detail.csv
$reportFile = ".\failed_tests_report.md"

$tritonCount = ($data | Where-Object { $_.ErrorCode -eq 'extract_slice' }).Count
$moduleNotFoundCount = ($data | Where-Object { $_.ErrorType -eq 'ModuleNotFoundError' }).Count
$npuErrorCount = ($data | Where-Object { $_.OriginalError -match 'NPU|aclnn|107001|161002' }).Count
$serverCrashCount = ($data | Where-Object { $_.OriginalError -match 'Server process exited with code -9' }).Count
$totalCount = $data.Count

$report = @"
# GitHub Actions Failed Tests Report

**Run ID**: 25726477805
**Repository**: Ascend/sglang
**Date**: 2026-05-12

## Summary Statistics

| Category | Count |
|----------|-------|
| **Total Failed Tests** | $totalCount |
| **Triton Error (extract_slice)** | $tritonCount |
| **ModuleNotFoundError** | $moduleNotFoundCount |
| **NPU Operator Errors** | $npuErrorCount |
| **Server Crash (exit code -9)** | $serverCrashCount |

## Error Type Analysis

### 1. Triton extract_slice Error ($tritonCount tests)

**Root Cause**: `AttributeError: module 'triton.language' has no attribute 'extract_slice'`

The Triton version used in NPU environment does not support the `extract_slice` function.

**Affected Tests**:
"@

$tritonTests = $data | Where-Object { $_.ErrorCode -eq 'extract_slice' }
foreach ($t in $tritonTests) {
    $report += "`n- $($t.TestName) (Job: $($t.JobName))"
}

$report += @"

### 2. ModuleNotFoundError ($moduleNotFoundCount tests)

**Root Cause**: Missing test utility modules in `sglang.test.ascend`

**Missing Modules**:
- `sglang.test.ascend.test_embedding_base`
- `sglang.test.ascend.test_no_hf_reward_base`
- `sglang.test.ascend.run_eval`
- `sglang.test.ascend.test_npu_logging`
- `sglang.test.ascend.output_capturer`

**Affected Tests**:
"@

$moduleTests = $data | Where-Object { $_.ErrorType -eq 'ModuleNotFoundError' }
foreach ($t in $moduleTests) {
    $report += "`n- $($t.TestName) - Missing: $($t.ErrorCode)"
}

$report += @"

### 3. ImportError - Constants Missing

**Root Cause**: Missing constant definitions in `test_ascend_utils.py`

**Missing Constants**:
- TRINITY_MINI_WEIGHTS_PATH
- SOLAR_10_7B_INSTRUCT_V1_0_WEIGHTS_PATH
- STARCODER2_7B_WEIGHTS_PATH
- OLMO_2_1124_7B_INSTRUCT_WEIGHTS_PATH
- DEEPSEEK_R1_0528_W8A8_WEIGHTS_PATH
- DEEPSEEK_R1_0528_W4A8_PER_CHANNEL_WEIGHTS_PATH
- IMAGES_EXAMPLE_PATH
- IMAGES_LOGO_PATH
- IMAGES_023_PATH
- CONFIG_YAML_PATH
- DOTS_OCR_WEIGHTS_PATH
- EAGLE3_LLAMA3_1_INSTRUCT_8B_WEIGHTS_PATH
- QWEN3_5_27B_MODEL_WEIGHTS_PATH
- QWEN3_4B_GGUF_Q4_K_M_WEIGHTS_PATH
- GPT_OSS_120B_BF16_WEIGHTS_PATH

### 4. NPU Operator Errors

**Examples**:
- `aclnnGather failed, error code 161002` - Gather kernel dimension mismatch
- `SetDevice error code 107001` - NPU device switching failure

### 5. Config Errors

- `BaichuanConfig missing attribute 'rope_theta'`

### 6. Server Process Crashed (exit code -9)

Multiple tests failed due to server process crash, possibly caused by:
- Out of memory
- NPU resource exhaustion
- Triton errors propagated to server

## Failed Tests by Job

"@

$jobs = $data | Group-Object JobName
foreach ($job in $jobs) {
    $report += "`n### $($job.Name) ($($job.Count) failures)`n`n"
    $report += "| Test Name | Error Type | Error Detail |`n"
    $report += "|-----------|------------|---------------|`n"
    foreach ($item in $job.Group) {
        $errorDetail = if ($item.ErrorCode) { $item.ErrorCode } else { $item.ErrorType }
        $report += "| $($item.TestName) | $($item.ErrorType) | $errorDetail |`n"
    }
}

$report += @"

## Recommended Fixes

1. **Triton Compatibility**: Upgrade Triton or implement NPU-compatible `extract_slice` function

2. **Add Missing Modules**: Create the following files in `sglang/test/ascend/`:
   - `test_embedding_base.py`
   - `test_no_hf_reward_base.py`
   - `run_eval.py`
   - `test_npu_logging.py`
   - `output_capturer.py`

3. **Add Missing Constants**: Update `test_ascend_utils.py` with all required path constants

4. **Fix BaichuanConfig**: Add `rope_theta` attribute to BaichuanConfig class

5. **Dependency Version**: Update xgrammar to version 0.1.32

6. **NPU Resource Management**: Investigate server crashes (exit code -9)

---

*Report generated automatically from GitHub Actions logs*
"@

[System.IO.File]::WriteAllText($reportFile, $report, [System.Text.Encoding]::UTF8)

Write-Host "Report saved to: $reportFile"