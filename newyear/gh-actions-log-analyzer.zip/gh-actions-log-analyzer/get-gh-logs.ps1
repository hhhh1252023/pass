param(
    [Parameter(Mandatory=$true)]
    [string]$Token,
    
    [Parameter(Mandatory=$true)]
    [string]$Repo,
    
    [Parameter(Mandatory=$true)]
    [string]$RunId,
    
    [string]$OutputDir = ".\gh-logs"
)

$headers = @{
    "Authorization" = "token $Token"
    "Accept" = "application/vnd.github.v3+json"
    "User-Agent" = "PowerShell-GH-Log-Fetcher"
}

$apiBase = "https://api.github.com/repos/$Repo"

Write-Host "Fetching jobs for run $RunId..." -ForegroundColor Cyan

$jobsUrl = "$apiBase/actions/runs/$RunId/jobs?per_page=100"
$jobs = @()
$page = 1

do {
    $response = Invoke-RestMethod -Uri "$jobsUrl&page=$page" -Headers $headers -Method Get
    $jobs += $response.jobs
    $page++
} while ($response.jobs.Count -eq 100)

Write-Host "Found $($jobs.Count) jobs" -ForegroundColor Green

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

foreach ($job in $jobs) {
    $jobName = $job.name -replace '[\\/:*?"<>|]', '_'
    $jobDir = Join-Path $OutputDir $jobName
    New-Item -ItemType Directory -Force -Path $jobDir | Out-Null
    
    Write-Host "`nProcessing job: $($job.name)" -ForegroundColor Yellow
    Write-Host "  Status: $($job.status), Conclusion: $($job.conclusion)" -ForegroundColor Gray
    
    $jobInfo = @{
        id = $job.id
        name = $job.name
        status = $job.status
        conclusion = $job.conclusion
        started_at = $job.started_at
        completed_at = $job.completed_at
        html_url = $job.html_url
        steps = @()
    }
    
    foreach ($step in $job.steps) {
        $stepInfo = @{
            name = $step.name
            number = $step.number
            status = $step.status
            conclusion = $step.conclusion
        }
        $jobInfo.steps += $stepInfo
    }
    
    $jobInfo | ConvertTo-Json -Depth 10 | Out-File (Join-Path $jobDir "job-info.json") -Encoding UTF8
    
    Write-Host "  Fetching logs..." -ForegroundColor Gray
    
    try {
        $logUrl = "$apiBase/actions/jobs/$($job.id)/logs"
        $logResponse = Invoke-WebRequest -Uri $logUrl -Headers $headers -Method Get -ErrorAction Stop -UseBasicParsing -TimeoutSec 60
        [System.IO.File]::WriteAllText((Join-Path $jobDir "full-log.txt"), $logResponse.Content, [System.Text.Encoding]::UTF8)
        Write-Host "  Log saved: $(Join-Path $jobDir 'full-log.txt')" -ForegroundColor Green
    }
    catch [System.Net.WebException] {
        if ($_.Exception.Message -match "timeout|timed out") {
            Write-Host "  Timeout - skipping this log" -ForegroundColor Yellow
        } else {
            Write-Host "  Error fetching log: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "  Error fetching log: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    Start-Sleep -Milliseconds 200
}

$summary = @{
    repo = $Repo
    run_id = $RunId
    total_jobs = $jobs.Count
    successful = ($jobs | Where-Object { $_.conclusion -eq 'success' }).Count
    failed = ($jobs | Where-Object { $_.conclusion -eq 'failure' }).Count
    cancelled = ($jobs | Where-Object { $_.conclusion -eq 'cancelled' }).Count
    skipped = ($jobs | Where-Object { $_.conclusion -eq 'skipped' }).Count
    output_dir = $OutputDir
}

$summary | ConvertTo-Json | Out-File (Join-Path $OutputDir "summary.json") -Encoding UTF8

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Summary:" -ForegroundColor Cyan
Write-Host "  Total jobs: $($summary.total_jobs)" -ForegroundColor White
Write-Host "  Successful: $($summary.successful)" -ForegroundColor Green
Write-Host "  Failed:     $($summary.failed)" -ForegroundColor Red
Write-Host "  Cancelled:  $($summary.cancelled)" -ForegroundColor Yellow
Write-Host "  Skipped:    $($summary.skipped)" -ForegroundColor Gray
Write-Host "  Output:     $OutputDir" -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan