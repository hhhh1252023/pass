---
name: gh-actions-log-analyzer
description: Use when analyzing GitHub Actions workflow run logs, fetching job logs from API, identifying failed tests, categorizing error types, and generating detailed reports. Use ONLY when user mentions GitHub Actions logs, CI/CD failures, or asks to analyze workflow runs.
---

# GitHub Actions Log Analyzer

Analyze GitHub Actions workflow run logs to identify failures, categorize errors, and generate reports.

## Usage

### Fetch logs from GitHub

```powershell
.\get-gh-logs.ps1 -Token "YOUR_GITHUB_TOKEN" -Repo "owner/repo" -RunId "RUN_ID" -OutputDir ".\logs"
```

**Parameters**:
- `-Token`: GitHub Personal Access Token (requires `repo` permission)
- `-Repo`: Repository name in format `owner/repo`
- `-RunId`: GitHub Actions run ID
- `-OutputDir`: Output directory for logs (default: `.\gh-logs`)

### Analyze logs and generate report

```powershell
.\analyze-detail-errors.ps1
```

This generates:
- `failed_tests_detail.csv` - Detailed CSV with all failed tests
- `failed_tests_detail.json` - JSON format data
- `failed_tests_report.md` - Comprehensive markdown report

## Output Structure

```
.\logs\
├── summary.json           # Run summary
├── job-name-1\
│   ├── job-info.json      # Job metadata
│   └── full-log.txt       # Full job log
├── job-name-2\
│   └── ...
└── ...

.\failed_tests_detail.csv  # Columns: JobName, TestName, TestPath, ErrorType, ErrorCode, OriginalError
.\failed_tests_report.md   # Full analysis report
```

## Error Categories

The analyzer identifies these error types:

1. **TritonError**: `AttributeError: module 'triton.language' has no attribute 'extract_slice'`
2. **ModuleNotFoundError**: Missing Python modules
3. **ImportError**: Missing imports or constants
4. **NPUError**: NPU operator failures (error codes 107001, 161002, etc.)
5. **ConfigError**: Missing config attributes (e.g., `rope_theta`)
6. **ServerCrash**: Server process exited with code -9
7. **PythonException**: General Python errors

## Examples

### Example 1: Fetch and analyze logs

User says: "分析这个GitHub Actions日志 https://github.com/owner/repo/actions/runs/12345"

Agent should:
1. Extract RunId from URL (12345)
2. Run `get-gh-logs.ps1` to fetch logs
3. Run `analyze-detail-errors.ps1` to analyze
4. Present summary to user

### Example 2: Specify output directory

User says: "把日志保存到 D:\analysis\logs"

Agent should:
```powershell
.\get-gh-logs.ps1 -Token "token" -Repo "owner/repo" -RunId "12345" -OutputDir "D:\analysis\logs"
```

### Example 3: Analyze existing logs

User says: "分析已下载的日志"

Agent should:
```powershell
.\analyze-detail-errors.ps1
```

## Getting GitHub Token

1. Visit https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Select `repo` permission
4. Copy generated token

## Files

- `get-gh-logs.ps1` - Fetch logs from GitHub API
- `analyze-detail-errors.ps1` - Parse logs and generate reports
- `generate-report.ps1` - Generate markdown summary report

## Notes

- Requires PowerShell 5.1 or higher
- Large runs may take several minutes to download
- Logs are saved in UTF-8 encoding